
document.querySelector('.rug-alert-button').addEventListener('click', function() {
    alert('Achtung! Rug-Gefahr erkannt!');
});

document.querySelector('.background').addEventListener('mousemove', function (e) {
    const x = e.clientX / window.innerWidth * 100;
    const y = e.clientY / window.innerHeight * 100;
    this.style.backgroundPosition = `${x}% ${y}%`;
});
